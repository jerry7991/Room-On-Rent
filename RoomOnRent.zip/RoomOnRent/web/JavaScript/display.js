/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function displayId()
{
    //alert("hi");
    document.getElementById("userId1").value=document.getElementById("userID").value;
}
function displayName()
{
    //alert("hi");
    
    document.getElementById("userName1").value=document.getElementById("userName").value;
}
function displayfname()
{
    //alert("hi");
    
    document.getElementById("fname1").value=document.getElementById("fname").value;
}
function displayAddress()
{
    //alert("hi");
    
    document.getElementById("address11").value=document.getElementById("address1").value;
}
function displayAddress2()
{
    //alert("hi");
    
    document.getElementById("address12").value=document.getElementById("address2").value;
}
function displayCountry()
{
    //alert("hi");
    
    document.getElementById("country1").value=document.getElementById("country").value;
}
function displayState()
{
    //alert("hi");
    
    document.getElementById("state1").value=document.getElementById("state").value;
}
function displayDist()
{
    //alert("hi");
    
    document.getElementById("district1").value=document.getElementById("district").value;
}
function displayCNO()
{
    //alert("hi");
    
    document.getElementById("cno1").value=document.getElementById("cno").value;
}
function displayMail()
{
    //alert("hi");
    
    document.getElementById("_mail1").value=document.getElementById("_mail").value;
}
function displayAdhar()
{
    //alert("hi");
    document.getElementById("addhar1").value=document.getElementById("addhar").value;
}
function displayPan()
{
    //alert("hi");
    
    document.getElementById("pan1").value=document.getElementById("pan").value;
}
function displayPassword()
{
    //alert("hi");
    
    document.getElementById("pas1").value=document.getElementById("pas").value;
}
function displayGender()
{
    //alert("hi");
    
    document.getElementById("userGender1").value=document.getElementById("gender1").value;
}
function displayGender1()
{
    //alert("hi");
    
    document.getElementById("userGender1").value=document.getElementById("gender").value;
}