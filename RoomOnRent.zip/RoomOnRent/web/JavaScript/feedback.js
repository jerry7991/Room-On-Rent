/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function updateFeedback(clicked_id)
{
    //alert(clicked_id);
    if(document.getElementById("feedback_div1").id==clicked_id)
    {
        document.getElementById("feedbackValue").value="1";
        document.getElementById("feedback_div1").style.opacity="1";
        document.getElementById("feedback_div2").style.opacity="0.4";
        document.getElementById("feedback_div3").style.opacity="0.4";
        document.getElementById("feedback_div4").style.opacity="0.4";
    }
    if(document.getElementById("feedback_div2").id==clicked_id)
    {
        document.getElementById("feedbackValue").value="2";
        document.getElementById("feedback_div2").style.opacity="1";
        document.getElementById("feedback_div1").style.opacity="0.4";
        document.getElementById("feedback_div3").style.opacity="0.4";
        document.getElementById("feedback_div4").style.opacity="0.4";
    }
    if(document.getElementById("feedback_div3").id==clicked_id)
    {
        document.getElementById("feedbackValue").value="3";
        document.getElementById("feedback_div3").style.opacity="1";
        document.getElementById("feedback_div2").style.opacity="0.4";
        document.getElementById("feedback_div1").style.opacity="0.4";
        document.getElementById("feedback_div4").style.opacity="0.4";
    }
    if(document.getElementById("feedback_div4").id==clicked_id)
    {
        document.getElementById("feedbackValue").value="4";
        document.getElementById("feedback_div4").style.opacity="1";
        document.getElementById("feedback_div2").style.opacity="0.4";
        document.getElementById("feedback_div3").style.opacity="0.4";
        document.getElementById("feedback_div1").style.opacity="0.4";
    }
}
function category(clicked_id)
{
    //alert("clicked_id");
    document.getElementById(clicked_id).style="background-color:#c9e83e;";
    if(document.getElementById("feedback_cat1").id==clicked_id)
    {
        document.getElementById("cat").value="Suggestion";
        document.getElementById("feedback_cat2").style="background-color:white;";
        document.getElementById("feedback_cat3").style="background-color:white;";
    }
    if(document.getElementById("feedback_cat2").id==clicked_id)
    {
        document.getElementById("cat").value="Something is not quite right";
        document.getElementById("feedback_cat1").style="background-color:white;";
        document.getElementById("feedback_cat3").style="background-color:white;";
    }
    if(document.getElementById("feedback_cat3").id==clicked_id)
    {
        document.getElementById("cat").value="Compliment";
        document.getElementById("feedback_cat1").style="background-color:white;";
        document.getElementById("feedback_cat2").style="background-color:white;";
    }
}
