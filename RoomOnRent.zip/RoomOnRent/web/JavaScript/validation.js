/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function validName()
{
    //alert("hi");
    var patternName=/^[A-Za-z ]{2,28}$/;
    /*
    [] -> It tells that what-what type of element allowed in input box and {minRange,maxRange} tells what should range of input text 
    */
    var name=document.getElementById("userName").value;
    if(!patternName.test(name))
    {
	//alert("Invalid user");
	document.getElementById("userName").style.border="2px dotted red";
	document.getElementById("sp").innerHTML="Invalid name";
	document.getElementById("sp").style.color="red";
        return false;
	}
	else
	{
	//alert("Valid user");
	document.getElementById("userName").style.border="2px solid lime";
	document.getElementById("sp").innerHTML="";
        return true;
	}
}
function checkNumber()
{
        var pattern=/^[0-9]{10}$/;
        var num=document.getElementById("cno").value;
        if(!pattern.test(num))
        {
                document.getElementById("cno").style.border="2px dotted red";
                document.getElementById("spNumber").innerHTML="Invalid number";
        }
        else
        {
                document.getElementById("cno").style.border="lime";
                document.getElementById("spNumber").innerHTML="";
        }
}       
function validFName()
{
    //alert("hi");
    var patternName=/^[A-Za-z ]{2,28}$/;
    /*
    [] -> It tells that what-what type of element allowed in input box and {minRange,maxRange} tells what should range of input text 
    */
    var name=document.getElementById("fname").value;
    if(!patternName.test(name))
	{
	//alert("Invalid user");
	document.getElementById("fname").style.border="2px dotted red";
	document.getElementById("spf").innerHTML="Invalid name";
	document.getElementById("spf").style.color="red";
        return false;
	}
	else
	{
	//alert("Valid user");
	document.getElementById("fname").style.border="2px solid lime";
	document.getElementById("spf").innerHTML="";
        return true;
	}
}
function checkMail()
{
    var pemail=/^[a-zA-Z0-9-_]+@[a-zA-Z0-9-_]+\.[a-zA-Z]{2,5}$/;
    var email=document.getElementById("_mail").value;
    if(!pemail.test(email))
    {
        document.getElementById("_mail").style.border="2px dotted red";
	document.getElementById("spm").innerHTML="Invalide mail";
        return false;
	}
	else
	{
	document.getElementById("_mail").style.border="2px solid lime";
	document.getElementById("spm").innerHTML="";
        return true;
	}
}
function validPassword()
{
    //alert("Hi");
    var pass=document.getElementById("pas").value;
    if(pass.length==0)
	{
	//alert("password required");
        return false;
	}
	else if(pass.length<=3)
	{
	document.getElementById("pas").style.border="2px solid red";
	document.getElementById("spPass").innerHTML="Week password";
	document.getElementById("spPass").style.color="red";
        return false;
	}
	else if(pass.length>3 && pass.length<=6)
	{
            document.getElementById("pas").style.border="2px solid yellow";
            document.getElementById("spPass").innerHTML="strong password";
            document.getElementById("spPass").style.color="yellow";
            return true;
	}
	else
	{
            document.getElementById("pas").style.border="2px solid green";
            document.getElementById("spPass").innerHTML="more strong password";
            document.getElementById("spPass").style.color="green";
            return true;
        }
}
function validAdhar()
{
    var adhar=document.getElementById("addhar").value;
    if(adhar.length !=13)
    {
     document.getElementById("addhar").style.border="2px solid red";
     document.getElementById("spAdd").innerHTML="Adhar number must be 14 digits";
     document.getElementById("spAdd").style.color="red";   
     return false;
    }
    else
    {
     document.getElementById("addhar").style.border="2px solid green";
     document.getElementById("spAdd").innerHTML="";
     document.getElementById("spAdd").style.color=""; 
     return true;
    }   
}
function matchPassword()
{
    var password=document.getElementById("pas").value;
    var reEnteredPassword=document.getElementById("repass").value;
    if(password==reEnteredPassword)
    {  
     document.getElementById("repass").style.border="2px solid green";
     document.getElementById("spRePass").innerHTML="";
     document.getElementById("spRePass").style.color=""; 
     return true;
    }
    else
    {  
     document.getElementById("repass").style.border="2px solid red";
     document.getElementById("spRePass").innerHTML="Mismatch password";
     document.getElementById("spRePass").style.color="red";    
     return false;
    }
}
function matchCaptcha()
{
    var captcha=document.getElementById("captcha").value;
    var capcode=document.getElementById("capcode").value;
    if(captcha==capcode)
    {  
     document.getElementById("capcode").style.border="2px solid green";
     document.getElementById("spcap").innerHTML="";
     document.getElementById("spcap").style.color=""; 
     return true;
    }
    else
    {  
     document.getElementById("capcode").style.border="2px solid red";
     document.getElementById("spcap").innerHTML="Mismatch Captcha";
     document.getElementById("spcap").style.color="red";    
     return false;
    }
}