/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var xmlHttp;
function showStates(str)
{
    //alert(str);
    if( typeof XMLHttpRequest !== "undefined")
    {
        xmlHttp=new XMLHttpRequest();    
        //alert("hi");
    }else if( window.ActiveXObject)
    {
        //alert("hi");
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
        return ;
    }
    if(xmlHttp===null)
    {
        alert("Browser does not support XMLHTTP request");
        return ;
    }
    var url= "http://localhost:8084/RoomOnRent/JavaScript/state.jsp";
    url += "?count="+str;
    xmlHttp.onreadystatechange = stateChange;
    xmlHttp.open("GET", url , true);
    xmlHttp.send(null);
}
function stateChange()
{
    if(xmlHttp.readyState === 4 || xmlHttp.readyState ==="complete")
    {
        document.getElementById("state").innerHTML=xmlHttp.responseText;
    }
}
function showDistrict(str)
{
     if( typeof XMLHttpRequest != "undefined")
    {
       
        xmlHttp=new XMLHttpRequest();    
    }else if( window.ActiveXObject)
    {
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
        return ;
    }
    if(xmlHttp==null)
    {
        alert("Browser does not support XMLHTTP request");
        return ;
    }
    var url="http://localhost:8084/RoomOnRent/JavaScript/district.jsp";
    url += "?count=" + str;
    xmlHttp.onreadystatechange = stateChange1;
    xmlHttp.open("GET", url , true);
    xmlHttp.send(null);
}
function stateChange1()
{
    if(xmlHttp.readyState === 4 || xmlHttp.readyState ==="complete")
    {
        document.getElementById("district").innerHTML=xmlHttp.responseText;
    }
}
