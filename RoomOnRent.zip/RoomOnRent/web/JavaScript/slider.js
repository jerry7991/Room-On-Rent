/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var img_array=["s1.jpg","s2.jfif","s3.jpg","s4.jpg","s5.jpg","s6.jpg","s7.jpeg","s8.png"];
var  i=0;
function moveslider()
{
    if(i==img_array.length)
    {
        i=0;
    }
    document.getElementById("img1").src="GALLERY/SLIDER/"+img_array[i];
    i++;
    window.setTimeout("moveslider()",3000);
}