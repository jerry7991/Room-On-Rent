/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectPackage;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import projectPackage.DbManager;
import java.nio.file.Files;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.sql.*;

/**
 *
 * @author Lenovo
 */
//@WebServlet("/upload")
@MultipartConfig
@WebServlet(name = "upload", urlPatterns = {"/upload"})
public class upload extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet upload</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet upload at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String userid=request.getParameter("userid");
            DbManager db=new DbManager();
            String dt=db.getDate();
            String roomType=request.getParameter("roomType");
            int maxrent=Integer.parseInt(request.getParameter("maxrent"));
            int minrent=Integer.parseInt(request.getParameter("minrent"));
            String addNotice=request.getParameter("addNotice");
            String status="1";
            String country=request.getParameter("country");
            String state=request.getParameter("state");
            String city=request.getParameter("district");
            String addrress=city+" , "+state+" , "+country;
            //file1
            Part p=request.getPart("photo1");
            String fname=p.getSubmittedFileName();
            InputStream is=p.getInputStream();
            File f=new File(request.getRealPath("/uploadfile"),userid+fname);
            Files.copy(is,f.toPath());
            
            String facilities="ebill"+request.getParameter("ebill")+" wbill"+request.getParameter("wbill")+ " kitchen"+request.getParameter("kitchen")+" bathroom"+request.getParameter("bathroom")+" parking"+request.getParameter("parking");
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/roomonrent","root","");
            String q="insert into room (userid,roomType , minrent, maxrent , addNotice , photo1,date,facilities,status, address) values('"+userid+"','"+roomType+"','"+minrent+"','"+maxrent+"','"+addNotice+"','"+userid+fname+"','"+dt+"','"+facilities+"','"+status+"','"+addrress+"')";
             PreparedStatement ps=con.prepareStatement(q);
            ps.executeUpdate();
             response.sendRedirect("LandLord/Events/success.jsp");
        } catch (Exception e) {
            e.printStackTrace();   // Prints what exception has been thrown 
            System.out.println(e); 
            response.sendRedirect("index.html?error="+e);
        }  
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
